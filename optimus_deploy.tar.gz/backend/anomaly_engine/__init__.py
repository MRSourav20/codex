from .dns_event_detector import SuspiciousEventDetector, SuspiciousEventType
